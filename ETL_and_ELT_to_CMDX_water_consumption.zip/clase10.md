cd C:\Users\rafae\OneDrive\Documentos\Crehana\ETL_and_ELT_to_CMDX_water_consumption

