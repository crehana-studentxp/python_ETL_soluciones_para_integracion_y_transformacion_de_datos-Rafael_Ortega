Crear cuenta
configuras S3
Configuras la RDS
Configuras tu computadora
Configuras tu ambiente de python

